// PWM.c
// Runs on LM3S811
// Use PWM0/PB0 to generate pulse-width modulated outputs
// Daniel Valvano
// December 29, 2011
// Modified by Lucas Holt and Matthew Halpern

/* This example accompanies the book
   "Embedded Systems: Real Time Interfacing to the Arm Cortex M3",
   ISBN: 978-1463590154, Jonathan Valvano, copyright (c) 2011
  Program 6.7, section 6.3.2

 Copyright 2011 by Jonathan W. Valvano, valvano@mail.utexas.edu
    You may use, edit, run or distribute this file
    as long as the above copyright notice remains
 THIS SOFTWARE IS PROVIDED "AS IS".  NO WARRANTIES, WHETHER EXPRESS, IMPLIED
 OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE.
 VALVANO SHALL NOT, IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL,
 OR CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.
 For more information about my classes, my research, and my books, see
 http://users.ece.utexas.edu/~valvano/
 */
#include "PWM.h"
#define PWM_ENABLE_R            (*((volatile unsigned long *)0x40028008))
#define PWM_ENABLE_PWM1EN       0x00000004  // PWM1 Output Enable//FIS
#define PWM_1_CTL_R             (*((volatile unsigned long *)0x40028080))
#define PWM_X_CTL_ENABLE        0x00000001  // PWM Block Enable
#define PWM_1_LOAD_R            (*((volatile unsigned long *)0x40028090))
#define PWM_1_CMPA_R            (*((volatile unsigned long *)0x40028098))
#define PWM_1_GENA_R            (*((volatile unsigned long *)0x400280A0))
#define PWM_1_CMPB_R            (*((volatile unsigned long *)0x4002809C))
#define PWM_1_GENB_R            (*((volatile unsigned long *)0x400280A4))
#define PWM_X_GENA_ACTCMPAD_ONE 0x000000C0  // Set the output signal to 1
#define PWM_X_GENA_ACTLOAD_ZERO 0x00000008  // Set the output signal to 0
//#define GPIO_PORTG_AFSEL_R      (*((volatile unsigned long *)0x40026420))
//#define GPIO_PORTG_DEN_R        (*((volatile unsigned long *)0x4002651C))
#define GPIO_PORTB_AFSEL_R      (*((volatile unsigned long *)0x40005420))
#define GPIO_PORTB_DEN_R        (*((volatile unsigned long *)0x4000551C))
#define GPIO_PORTB_8MA_R        (*((volatile unsigned long *)0x40005508))
#define GPIO_PORTB_DATA_R       (*((volatile unsigned long *)0x400053FC))
#define GPIO_PORTB_DIR_R        (*((volatile unsigned long *)0x40005400))
#define SYSCTL_RCC_R            (*((volatile unsigned long *)0x400FE060))
#define SYSCTL_RCC_USEPWMDIV    0x00100000  // Enable PWM Clock Divisor
#define SYSCTL_RCC_PWMDIV_M     0x000E0000  // PWM Unit Clock Divisor
#define SYSCTL_RCC_PWMDIV_2     0x00000000  // /2
#define SYSCTL_RCGC0_R          (*((volatile unsigned long *)0x400FE100))
#define SYSCTL_RCGC0_PWM        0x00100000  // PWM Clock Gating Control
#define SYSCTL_RCGC2_R          (*((volatile unsigned long *)0x400FE108))
#define SYSCTL_RCGC2_GPIOH      0x00000002  // Port B Clock Gating Control
// period is 16-bit number of PWM clock cycles in one period (3<=period)
// duty is number of PWM clock cycles output is high  (2<=duty<=period-1)
// PWM clock rate = processor clock rate/SYSCTL_RCC_PWMDIV
//                = BusClock/2 
//                = 50 MHz/2 = 25 MHz (in this example)
// PWM clock rate = processor clock rate/SYSCTL_RCC_PWMDIV
void PWM1_Init(unsigned short period){
  volatile unsigned long delay;
  SYSCTL_RCGC0_R |= SYSCTL_RCGC0_PWM;   // 1)activate PWM	
  SYSCTL_RCGC2_R |= SYSCTL_RCGC2_GPIOH; // 2)activate port B
  delay = SYSCTL_RCGC2_R;               // allow time to finish activating
  GPIO_PORTB_AFSEL_R |= 0x01;           //  enable alt funct on PB0		
  GPIO_PORTB_DEN_R |= 0x01;             //  enable digital I/O on PB0
  GPIO_PORTB_8MA_R |= 0x01;			    //  enable 8ma current
  SYSCTL_RCC_R |= SYSCTL_RCC_USEPWMDIV; // 3) use PWM divider
  SYSCTL_RCC_R &= ~SYSCTL_RCC_PWMDIV_M; //    clear PWM divider field
  SYSCTL_RCC_R += SYSCTL_RCC_PWMDIV_2;  //    configure for /2 divider
  PWM_1_CTL_R = 0x00000000;             // 4) re-loading mode
  PWM_1_GENA_R = 0x00000001;
  PWM_1_LOAD_R = period;    			// 5) cycles needed to count down to 0
  PWM_1_CTL_R |= 0x00000001;			// 7) start PWM0
  PWM_ENABLE_R|= 0x00000004;					 
}
