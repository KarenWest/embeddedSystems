// I2C.c
// Runs on LM3S811
// Provide a function that initializes the I2C0 module to
// derived from an interface with an HMC6352 compass or TMP102 thermometer.
// Daniel Valvano
// December 29, 2011

/* This example accompanies the book
   Embedded Systems: Real-Time Operating Systems for the Arm Cortex-M3, Volume 3,  
   ISBN: 978-1466468863, Jonathan Valvano, copyright (c) 2012

 Copyright 2012 by Jonathan W. Valvano, valvano@mail.utexas.edu
    You may use, edit, run or distribute this file
    as long as the above copyright notice remains

 THIS SOFTWARE IS PROVIDED "AS IS".  NO WARRANTIES, WHETHER EXPRESS, IMPLIED
 OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE.
 VALVANO SHALL NOT, IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL,
 OR CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.
 For more information about my classes, my research, and my books, see
 http://users.ece.utexas.edu/~valvano/
 */
#include "I2C.h"
// I2CSCL connected to PB2 and to pin 4 of HMC6352 compass or pin 3 of TMP102 thermometer
// I2CSDA connected to PB3 and to pin 3 of HMC6352 compass or pin 2 of TMP102 thermometer
// SCL and SDA lines pulled to +3.3 V with 10 k resistors (part of breakout module)
// ADD0 pin of TMP102 thermometer connected to GND

#define GPIO_PORTB_AFSEL_R      (*((volatile unsigned long *) 0x40005420))
#define GPIO_PORTB_ODR_R        (*((volatile unsigned long *) 0x4000550C))
#define GPIO_PORTB_DEN_R        (*((volatile unsigned long *) 0x4000551C))
#define GPIO_PORTB_PUR_R        (*((volatile unsigned long *) 0x40005510))
#define GPIO_PORTB_8MA_R        (*((volatile unsigned long *) 0x40005508)) 
#define I2C0_MASTER_MTPR_R      (*((volatile unsigned long *) 0x4002000C))
#define I2C0_MASTER_MCR_R       (*((volatile unsigned long *) 0x40020020))
#define I2C_MCR_MFE             0x00000010  // I2C Master Function Enable
#define SYSCTL_RCGC1_R          (*((volatile unsigned long *) 0x400FE104))
#define SYSCTL_RCGC2_R          (*((volatile unsigned long *) 0x400FE108))
#define SYSCTL_RCGC1_I2C0       0x00001000  // I2C0 Clock Gating Control
#define SYSCTL_RCGC2_GPIOB      0x00000002  // port B Clock Gating Control
// ***********I2C_Init******************
// Initialize I2C 100 kps, PB2 PB3
// Inputs:  none
// Outputs: none
void I2C_Init(void){
  volatile unsigned long delay;
  SYSCTL_RCGC1_R |= SYSCTL_RCGC1_I2C0;  // activate I2C0
  SYSCTL_RCGC2_R |= SYSCTL_RCGC2_GPIOB; // activate port B
  delay = SYSCTL_RCGC2_R;               // allow time to finish activating
  GPIO_PORTB_AFSEL_R |= 0x0C;           // enable alt funct on PB2,3
  GPIO_PORTB_ODR_R |= 0x0C;             // enable open drain on PB2,3
  GPIO_PORTB_DEN_R |= 0x0C;
  I2C0_MASTER_MCR_R= I2C_MCR_MFE;      // master function enable
  I2C0_MASTER_MTPR_R= 0x00000018;      // configure for 100 kbps clock
}
// I2CSCL connected to PB2 and to pin 4 of HMC6352 compass or pin 3 of TMP102 thermometer
// I2CSDA connected to PB3 and to pin 3 of HMC6352 compass or pin 2 of TMP102 thermometer
// SCL and SDA lines pulled to +3.3 V with 10 k resistors (part of breakout module)
// ADD0 pin of TMP102 thermometer connected to GND

#define I2C0_MASTER_MSA_R       (*((volatile unsigned long *)0x40020000))
#define I2C0_MASTER_MCS_R       (*((volatile unsigned long *)0x40020004))
#define I2C0_MASTER_MDR_R       (*((volatile unsigned long *)0x40020008))
#define I2C_MCS_ACK             0x00000008  // Data Acknowledge Enable
#define I2C_MCS_DATACK          0x00000008  // Acknowledge Data
#define I2C_MCS_ADRACK          0x00000004  // Acknowledge Address
#define I2C_MCS_STOP            0x00000004  // Generate STOP
#define I2C_MCS_START           0x00000002  // Generate START
#define I2C_MCS_ERROR           0x00000002  // Error
#define I2C_MCS_RUN             0x00000001  // I2C Master Enable
#define I2C_MCS_BUSY            0x00000001  // I2C Busy

// sends one byte to specified slave
// Note for HMC6352 compass only:
// Used with 'S', 'W', 'O', 'C', 'E', 'L', and 'A' commands
// For 'A' commands, I2C_Recv2() should also be called
// Note for TMP102 thermometer only:
// Used to change the pointer register
// Returns 0 if successful, nonzero if error
unsigned long I2C_Send1(char slave, unsigned char data1){
  while(I2C0_MASTER_MCS_R&I2C_MCS_BUSY){};// wait for I2C ready
  I2C0_MASTER_MSA_R = (slave<<1)&0xFE;    // MSA[7:1] is slave address
  I2C0_MASTER_MSA_R &= ~0x01;             // MSA[0] is 0 for send
  I2C0_MASTER_MDR_R = data1&0xFF;         // prepare first byte
  I2C0_MASTER_MCS_R = (0
                       & ~I2C_MCS_ACK     // no data ack (no data on send)
                       | I2C_MCS_STOP     // generate stop
                       | I2C_MCS_START    // generate start/restart
                       | I2C_MCS_RUN);    // master enable
  while(I2C0_MASTER_MCS_R&I2C_MCS_BUSY){};// wait for transmission done
                                          // return error bits
  return (I2C0_MASTER_MCS_R&(I2C_MCS_DATACK|I2C_MCS_ADRACK|I2C_MCS_ERROR));
}
// sends two bytes to specified slave
// Note for HMC6352 compass only:
// Used with 'r' and 'g' commands
//  For 'r' and 'g' commands, I2C_Recv() should also be called
// Note for TMP102 thermometer only:
// Used to change the top byte of the contents of the pointer register
//  This will work but is probably not what you want to do.
// Returns 0 if successful, nonzero if error
unsigned long I2C_Send2(char slave, unsigned char data1, unsigned char data2){
  while(I2C0_MASTER_MCS_R&I2C_MCS_BUSY){};// wait for I2C ready
  I2C0_MASTER_MSA_R = (slave<<1)&0xFE;    // MSA[7:1] is slave address
  I2C0_MASTER_MSA_R &= ~0x01;             // MSA[0] is 0 for send
  I2C0_MASTER_MDR_R = data1&0xFF;         // prepare first byte
  I2C0_MASTER_MCS_R = (0
                       & ~I2C_MCS_ACK     // no data ack (no data on send)
                       & ~I2C_MCS_STOP    // no stop
                       | I2C_MCS_START    // generate start/restart
                       | I2C_MCS_RUN);    // master enable
  while(I2C0_MASTER_MCS_R&I2C_MCS_BUSY){};// wait for transmission done
                                          // check error bits
  if((I2C0_MASTER_MCS_R&(I2C_MCS_DATACK|I2C_MCS_ADRACK|I2C_MCS_ERROR)) != 0){
    I2C0_MASTER_MCS_R = (0                // send stop if nonzero
                       & ~I2C_MCS_ACK     // no data ack (no data on send)
                       | I2C_MCS_STOP     // stop
                       & ~I2C_MCS_START   // no start/restart
                       & ~I2C_MCS_RUN);   // master disable
                                          // return error bits if nonzero
    return (I2C0_MASTER_MCS_R&(I2C_MCS_DATACK|I2C_MCS_ADRACK|I2C_MCS_ERROR));
  }
  I2C0_MASTER_MDR_R = data2&0xFF;         // prepare second byte
  I2C0_MASTER_MCS_R = (0
                       & ~I2C_MCS_ACK     // no data ack (no data on send)
                       | I2C_MCS_STOP     // generate stop
                       & ~I2C_MCS_START   // no start/restart
                       | I2C_MCS_RUN);    // master enable
  while(I2C0_MASTER_MCS_R&I2C_MCS_BUSY){};// wait for transmission done
                                          // return error bits
  return (I2C0_MASTER_MCS_R&(I2C_MCS_DATACK|I2C_MCS_ADRACK|I2C_MCS_ERROR));
}
// sends three bytes to specified slave
// Note for HMC6352 compass only:
// Used with 'w' and 'G' commands
// Note for TMP102 thermometer only:
// Used to change the contents of the pointer register
// Returns 0 if successful, nonzero if error
unsigned long I2C_Send3(char slave, unsigned char data1, unsigned char data2, unsigned char data3){
  while(I2C0_MASTER_MCS_R&I2C_MCS_BUSY){};// wait for I2C ready
  I2C0_MASTER_MSA_R = (slave<<1)&0xFE;    // MSA[7:1] is slave address
  I2C0_MASTER_MSA_R &= ~0x01;             // MSA[0] is 0 for send
  I2C0_MASTER_MDR_R = data1&0xFF;         // prepare first byte
  I2C0_MASTER_MCS_R = (0
                       & ~I2C_MCS_ACK     // no data ack (no data on send)
                       & ~I2C_MCS_STOP    // no stop
                       | I2C_MCS_START    // generate start/restart
                       | I2C_MCS_RUN);    // master enable
  while(I2C0_MASTER_MCS_R&I2C_MCS_BUSY){};// wait for transmission done
                                          // check error bits
  if((I2C0_MASTER_MCS_R&(I2C_MCS_DATACK|I2C_MCS_ADRACK|I2C_MCS_ERROR)) != 0){
    I2C0_MASTER_MCS_R = (0                // send stop if nonzero
                       & ~I2C_MCS_ACK     // no data ack (no data on send)
                       | I2C_MCS_STOP     // stop
                       & ~I2C_MCS_START   // no start/restart
                       & ~I2C_MCS_RUN);   // master disable
                                          // return error bits if nonzero
    return (I2C0_MASTER_MCS_R&(I2C_MCS_DATACK|I2C_MCS_ADRACK|I2C_MCS_ERROR));
  }
  I2C0_MASTER_MDR_R = data2&0xFF;         // prepare second byte
  I2C0_MASTER_MCS_R = (0
                       & ~I2C_MCS_ACK     // no data ack (no data on send)
                       & ~I2C_MCS_STOP    // no stop
                       & ~I2C_MCS_START   // no start/restart
                       | I2C_MCS_RUN);    // master enable
  while(I2C0_MASTER_MCS_R&I2C_MCS_BUSY){};// wait for transmission done
                                          // check error bits
  if((I2C0_MASTER_MCS_R&(I2C_MCS_DATACK|I2C_MCS_ADRACK|I2C_MCS_ERROR)) != 0){
    I2C0_MASTER_MCS_R = (0                // send stop if nonzero
                       & ~I2C_MCS_ACK     // no data ack (no data on send)
                       | I2C_MCS_STOP     // stop
                       & ~I2C_MCS_START   // no start/restart
                       & ~I2C_MCS_RUN);   // master disable
                                          // return error bits if nonzero
    return (I2C0_MASTER_MCS_R&(I2C_MCS_DATACK|I2C_MCS_ADRACK|I2C_MCS_ERROR));
  }
  I2C0_MASTER_MDR_R = data3&0xFF;         // prepare third byte
  I2C0_MASTER_MCS_R = (0
                       & ~I2C_MCS_ACK     // no data ack (no data on send)
                       | I2C_MCS_STOP     // generate stop
                       & ~I2C_MCS_START   // no start/restart
                       | I2C_MCS_RUN);    // master enable
  while(I2C0_MASTER_MCS_R&I2C_MCS_BUSY){};// wait for transmission done
                                          // return error bits
  return (I2C0_MASTER_MCS_R&(I2C_MCS_DATACK|I2C_MCS_ADRACK|I2C_MCS_ERROR));
}
