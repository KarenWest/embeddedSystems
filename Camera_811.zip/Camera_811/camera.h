// Lucas Holt & Matt Halpern Camera TCM8230MD initialization and Capture

// This code will intialize a TCM8230MD to capture pictures with a resolution of 128x94 
// Oled on LM3S1968/LM3S8962 kits is 128x94)
// The frame rate is set up for 1.875FPS

/* This example accompanies the book
   Embedded Systems: Real-Time Operating Systems for the Arm Cortex-M3, Volume 3,  
   ISBN: 978-1466468863, Jonathan Valvano, copyright (c) 2012

  Program 6.4, section 6.7

 Copyright 2012 by Jonathan W. Valvano, valvano@mail.utexas.edu
    You may use, edit, run or distribute this file
    as long as the above copyright notice remains
 THIS SOFTWARE IS PROVIDED "AS IS".  NO WARRANTIES, WHETHER EXPRESS, IMPLIED
 OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE.
 VALVANO SHALL NOT, IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL,
 OR CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.
 For more information about my classes, my research, and my books, see
 http://users.ece.utexas.edu/~valvano/
 */
//------------Camera_Init------------
// Initialize camera
void Camera_Init(void);

//------------Camera_Capture------------
// Take a picture
void Camera_Capture(void);

// shared global
// two pixels per byte, 4 bit grey scale
// resolution to 128(columns)x96(rows)
extern unsigned char Camera_Picture[6016];

