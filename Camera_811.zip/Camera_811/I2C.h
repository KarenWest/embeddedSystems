// I2C.h
// Runs on LM3S811
// Provide a function that initializes the I2C0 module to
// derived from the interface with an HMC6352 compass or TMP102 thermometer.
// Daniel Valvano
// December 29, 2011

/* This example accompanies the book
   Embedded Systems: Real-Time Operating Systems for the Arm Cortex-M3, Volume 3,  
   ISBN: 978-1466468863, Jonathan Valvano, copyright (c) 2012

 Copyright 2012 by Jonathan W. Valvano, valvano@mail.utexas.edu
    You may use, edit, run or distribute this file
    as long as the above copyright notice remains

 THIS SOFTWARE IS PROVIDED "AS IS".  NO WARRANTIES, WHETHER EXPRESS, IMPLIED
 OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE.
 VALVANO SHALL NOT, IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL,
 OR CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.
 For more information about my classes, my research, and my books, see
 http://users.ece.utexas.edu/~valvano/
 */
 
// ***********I2C_Init******************
// Initialize I2C 100 kps, PB2 PB3
// Inputs:  none
// Outputs: none
void I2C_Init(void);

// I2C communication commands

// ***********I2C_Send1******************
// sends one byte to specified slave
// Inputs: slave is address
//         data1 are data to be sent
// Returns 0 if successful, nonzero if error
unsigned long I2C_Send1(char slave, unsigned char data1);

// ***********I2C_Send2******************
// sends two bytes to specified slave
// Inputs: slave is address
//         data1, data2 are data to be sent
// Returns 0 if successful, nonzero if error
unsigned long I2C_Send2(char slave, unsigned char data1, unsigned char data2);

// ***********I2C_Send3******************
// sends three bytes to specified slave
// Inputs: slave is address
//         data1, data2, data3 are data to be sent
// Returns 0 if successful, nonzero if error
unsigned long I2C_Send3(char slave, unsigned char data1, unsigned char data2, unsigned char data3);


